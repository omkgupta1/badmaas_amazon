"""Synthetic decoy twins for the train split.

Test decoy businesses appear as 2+ S2/S3 records sharing their own shifted house number; train
decoys are almost always single records, so the consensus features (other records agree on the
query's number) accept test decoys. After train blocking, a share of the eligible train decoys —
orphan records whose top stage-0 candidate has a similar name and a different house number — get a
copy record: same address (so the same shifted number), lightly re-noised name, formatted like its
(possibly flipped) source. The copy inherits the original's candidate rows (label 0) and is added
to records_q, raw_q and q_true, so features, context and collective features see real twin groups
and train OOF becomes a test-like metric. Rates per country match the decoy excess measured on test.

Synthetic query ids are >= the real query count stored in records_q/_DONE; ``strip_synthetic``
removes everything this stage added (run before any re-blocking).
"""
from __future__ import annotations

import multiprocessing as mp
import sys

import numpy as np
import polars as pl

from .config import lexicon_dir, split_dir
from .prep import _init_worker, _parse_chunk
from .utils import LOG, chunks, list_parts, load_json, part_path, save_json, write_df

MARKER = "_AUGMENTED"
_LEGAL = {
    "US": ["Inc", "LLC", "Co", "Corp", "Ltd", "Group"],
    "India": ["Pvt Ltd", "Private Limited", "LLP", "Ltd", "Limited"],
}
_LEGAL_DEFAULT = ["Inc", "Ltd", "Co", "Group"]
_LEGAL_WORDS = {w.lower().strip(".") for ws in list(_LEGAL.values()) + [_LEGAL_DEFAULT]
                for x in ws for w in x.split()} | {"l.l.c", "llc.", "inc.", "pvt", "private"}


def n_real_queries(cfg: dict) -> int:
    return int(load_json(split_dir(cfg, "train") / "records_q" / "_DONE")["rows"])


def strip_synthetic(cfg: dict) -> int:
    """Remove synthetic records, raw rows, truth entries and candidate rows added by augment."""
    out = split_dir(cfg, "train")
    if not (out / "records_q" / "_DONE").exists():
        return 0
    n_real = n_real_queries(cfg)
    removed = 0
    for p in list_parts(out / "records_q"):
        if pl.scan_parquet(p).select(pl.col("idx").min()).collect().item() >= n_real:
            p.unlink()
            removed += 1
    raw_path = out / "raw_q.parquet"
    if raw_path.exists():
        n_raw = pl.scan_parquet(raw_path).select(pl.len()).collect().item()
        if n_raw > n_real:
            write_df(pl.read_parquet(raw_path).filter(pl.col("idx") < n_real), raw_path)
    qt_path = out / "q_true.npy"
    if qt_path.exists():
        qt = np.load(qt_path)
        if len(qt) > n_real:
            np.save(qt_path, qt[:n_real])
    cand = out / "cand"
    for p in list_parts(cand) if cand.exists() else []:  # also cleans an augment that crashed
        if pl.scan_parquet(p).select(pl.col("q").max()).collect().item() >= n_real:
            write_df(pl.read_parquet(p).filter(pl.col("q") < n_real), p)
    if (cand / MARKER).exists():
        (cand / MARKER).unlink()
    if removed:
        LOG.info("augment: removed %d synthetic record parts", removed)
    return removed


def _noisy_name(name: str, country: str, rng: np.random.Generator, p_noise: float) -> str:
    toks = name.split()
    if not toks or rng.random() >= p_noise:
        return name
    op = rng.integers(4)
    last = toks[-1].lower().strip(".,()")
    if op == 0 and last not in _LEGAL_WORDS:                      # add a legal form
        forms = _LEGAL.get(country, _LEGAL_DEFAULT)
        toks.append(forms[rng.integers(len(forms))])
    elif op == 1 and len(toks) >= 3:                              # drop the last token
        toks = toks[:-1]
    elif op == 2:                                                 # duplicate the last token
        toks.append(toks[-1])
    elif op == 3 and len(toks) >= 2:                              # swap two adjacent tokens
        i = int(rng.integers(len(toks) - 1))
        toks[i], toks[i + 1] = toks[i + 1], toks[i]
    return " ".join(toks)


def _formatted(name: str, addr: str, src: int, country: str, rng: np.random.Generator,
               p_s2_upper: dict) -> tuple[str, str]:
    """Casing of the copy follows its source (S2 addresses are mostly upper case in the US)."""
    if src == 2:
        if rng.random() < float(p_s2_upper.get(country, p_s2_upper.get("default", 0.5))):
            addr = addr.upper()
        if rng.random() < 0.2:
            name = name.upper()
    else:
        if addr and addr == addr.upper() and rng.random() < 0.95:
            addr = addr.title()
        if name and name == name.upper() and rng.random() < 0.8:
            name = name.title()
    return name, addr


def _parse(raw: pl.DataFrame, cfg: dict) -> pl.DataFrame:
    lex = lexicon_dir(cfg)
    indic = load_json(lex / "indic.json")
    addr_lex = load_json(lex / "address_train.json")
    n_workers = max(1, int(cfg["runtime"]["n_workers"]))
    tasks = [(raw["business_name"].slice(a, b - a).to_list(),
              raw["business_address"].slice(a, b - a).to_list(),
              raw["country"].slice(a, b - a).to_list()) for a, b in chunks(raw.height, 25_000)]
    ctx = mp.get_context("spawn" if sys.platform == "darwin" else "fork")
    with ctx.Pool(n_workers, initializer=_init_worker, initargs=(indic, addr_lex, False)) as pool:
        parts = pool.map(_parse_chunk, tasks)
    return pl.concat(parts, how="vertical")


def run_augment(cfg: dict) -> dict:
    out = split_dir(cfg, "train")
    cand_dir = out / "cand"
    a = cfg.get("augment", {})
    if not a.get("enabled", False):
        LOG.info("augment: disabled")
        return {}
    if (cand_dir / MARKER).exists():
        LOG.info("augment: cached")
        return load_json(cand_dir / MARKER)
    strip_synthetic(cfg)
    n_real = n_real_queries(cfg)
    rng = np.random.default_rng(int(cfg["runtime"]["seed"]) + 17)
    q_true = np.load(out / "q_true.npy")
    raw = pl.read_parquet(out / "raw_q.parquet")
    q_country = raw["country"].to_numpy()
    rates, default_rate = a.get("rate", {}), float(a.get("default_rate", 0.0))

    # 1. choose decoys per cand part; synthetic ids are consecutive within each part
    parts = list_parts(cand_dir)
    chosen, next_id = [], n_real
    for p in parts:
        t = pl.read_parquet(p, columns=["q", "s0_rank", "name_ratio0", "hn_eq0"]).filter(
            (pl.col("s0_rank") == 1) & (pl.col("name_ratio0") >= float(a["min_name_ratio"]))
            & (pl.col("hn_eq0") == 0))
        q = np.sort(t["q"].to_numpy().astype(np.int64))
        q = q[q_true[q] < 0]
        r = np.array([float(rates.get(c, default_rate)) for c in q_country[q]])
        q = q[rng.random(len(q)) < r]
        chosen.append((q, np.arange(next_id, next_id + len(q), dtype=np.int64)))
        next_id += len(q)
    orig = np.concatenate([c[0] for c in chosen]) if chosen else np.zeros(0, np.int64)
    new = np.concatenate([c[1] for c in chosen]) if chosen else np.zeros(0, np.int64)
    n_syn = len(orig)
    if n_syn == 0:
        save_json({"n_syn": 0, "n_real": n_real}, cand_dir / MARKER)
        return {"n_syn": 0}

    # 2. synthetic raw rows (source flipped or kept, re-noised name, source-style casing)
    src = raw["src"].to_numpy()[orig].astype(np.int64)
    flip = rng.random(n_syn) >= float(a.get("same_source_frac", 0.5))
    new_src = np.where(flip, 5 - src, src)
    names, addrs = [], []
    p_noise = float(a.get("name_noise", 0.6))
    p_upper = a.get("s2_address_upper", {"US": 0.9, "India": 0.25, "default": 0.5})
    for nm, ad, c, sv in zip(raw["business_name"].gather(orig).to_list(),
                             raw["business_address"].gather(orig).to_list(),
                             q_country[orig].tolist(), new_src.tolist()):
        nm = _noisy_name(nm, c, rng, p_noise)
        nm, ad = _formatted(nm, ad, sv, c, rng, p_upper)
        names.append(nm)
        addrs.append(ad)
    syn_raw = pl.DataFrame({
        "idx": new, "entity_id": [f"SYN{int(sv)}-{int(i)}" for sv, i in zip(new_src, new)],
        "src": new_src, "business_name": names, "business_address": addrs,
        "country": q_country[orig],
    }).cast(dict(raw.schema))
    write_df(pl.concat([raw, syn_raw], how="vertical"), out / "raw_q.parquet")
    del raw

    # 3. parsed records -> one extra records_q part
    rec_parts = list_parts(out / "records_q")
    schema = pl.read_parquet_schema(rec_parts[0])
    parsed = _parse(syn_raw, cfg)
    rec = pl.concat([syn_raw.select(["idx", "entity_id", "src", "country"]), parsed],
                    how="horizontal").select(list(schema)).cast(dict(schema))
    write_df(rec, part_path(out / "records_q", len(rec_parts)))
    np.save(out / "q_true.npy", np.concatenate([q_true, np.full(n_syn, -1, q_true.dtype)]))

    # 4. candidate rows: the copy inherits its original's candidates (all label 0)
    max_pid = max(pl.scan_parquet(p).select(pl.col("pair_id").max()).collect().item()
                  for p in parts)
    next_pid = int(max_pid) + 1
    for p, (q, ids) in zip(parts, chosen):
        if len(q) == 0:
            continue
        df = pl.read_parquet(p)
        m = pl.DataFrame({"q": q, "q_new": ids}).cast({"q": df.schema["q"], "q_new": df.schema["q"]})
        extra = (df.join(m, on="q", how="inner").drop("q").rename({"q_new": "q"})
                 .select(df.columns).sort(["q", "s0_rank"]))
        extra = extra.with_columns(
            pl.int_range(next_pid, next_pid + extra.height, dtype=df.schema["pair_id"])
            .alias("pair_id"), pl.lit(0, dtype=df.schema["label"]).alias("label"))
        next_pid += extra.height
        write_df(pl.concat([df, extra], how="vertical"), p)
    info = {"n_syn": n_syn, "n_real": n_real,
            "per_country": {c: int((q_country[orig] == c).sum())
                            for c in sorted(set(q_country[orig].tolist()))},
            "flipped_source_share": float(flip.mean())}
    save_json(info, cand_dir / MARKER)
    LOG.info("augment: %s", info)
    return info
