import numpy as np

from src.augment import _formatted, _noisy_name
from src.context_features import s_level_features
from src.features import _id_runs


def test_noisy_name_is_light():
    rng = np.random.default_rng(0)
    assert _noisy_name("Acme Holdings", "US", rng, 0.0) == "Acme Holdings"
    for _ in range(50):
        out = _noisy_name("Acme Blue Holdings", "US", rng, 1.0)
        assert set(out.split()) - {"Acme", "Blue", "Holdings", "Inc", "LLC", "Co", "Corp", "Ltd",
                                   "Group"} == set()


def test_formatted_follows_source():
    rng = np.random.default_rng(0)
    _, addr = _formatted("Acme", "12 Main St, Springfield, IL", 2, "US", rng, {"US": 1.0})
    assert addr == "12 MAIN ST, SPRINGFIELD, IL"
    _, addr = _formatted("Acme", "12 MAIN ST, SPRINGFIELD, IL", 3, "US", np.random.default_rng(1),
                         {"US": 1.0})
    assert addr != addr.upper()


def test_id_runs_split_at_gaps():
    ids = np.array([7, 5, 6, 2_000_001, 2_000_000, 6])
    assert _id_runs(ids) == [(5, 7), (2_000_000, 2_000_001)]
    assert _id_runs(np.array([3])) == [(3, 3)]


def test_twin_group_is_not_the_best_supported_number():
    # S1 0 at house number 150; its group: three records at 150 (true), two twins at 151
    s = np.zeros(5, dtype=np.int64)
    q = np.arange(5)
    q_hn = np.array([150, 150, 150, 151, 151])
    f = s_level_features(s, q, np.ones(5, np.float32), np.ones(5, bool), q_hn,
                         np.array([2, 3, 2, 2, 3]), np.array([150]), 1)
    assert f["g_n_hn"].tolist() == [2.0] * 5
    assert f["g_hn_b_is_max"].tolist() == [1, 1, 1, 0, 0]
    assert f["g_hn_a_is_max"].tolist() == [1] * 5
    assert f["g_hn_ba_diff"][3] < 0 < 1 + f["g_hn_ba_diff"][0]


def test_nan_augment_blanks_state_only_for_non_empty_addresses():
    from src.train_gbdt import nan_augment
    cols = ["state_eq", "b_addr_empty", "n_ratio"]
    X = np.zeros((2000, 3), dtype=np.float32)
    X[:, 0] = 1.0
    X[1000:, 1] = 1.0                      # second half: empty address
    cfg = {"model": {"nan_augment": {"cols": ["state_eq"], "frac": 0.35}}}
    nan_augment(X, cols, cfg, 0)
    blank = np.isnan(X[:, 0])
    assert 0.25 < blank[:1000].mean() < 0.45 and not blank[1000:].any()
    assert not np.isnan(X[:, 2]).any()


def test_token_space_idf_is_per_country():
    from src.features import TokenSpace
    ts = TokenSpace(["rue paris a", "rue lyon b", "main st x"], ["rue paris a", "main st y"],
                    np.array(["FR", "FR", "US"]), np.array(["FR", "US"]))
    shared = TokenSpace(["rue paris a", "rue lyon b", "main st x"], ["rue paris a", "main st y"])
    s, q = np.array([0]), np.array([0])
    # "rue" is in 3 of 3 French docs: weighted less than when mixed with US docs
    assert ts.pair(s, q)["inter_idf"][0] < shared.pair(s, q)["inter_idf"][0]
